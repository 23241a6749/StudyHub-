export interface Message {
  category: string;
  content: string;
  timestamp: string;
  important: boolean;
}