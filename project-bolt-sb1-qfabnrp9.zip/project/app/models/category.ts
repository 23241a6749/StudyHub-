export interface Category {
  name: string;
  enabled: boolean;
}