import { Observable } from '@nativescript/core';
import { Message } from '../../models/message';
import { Category } from '../../models/category';

export class DashboardViewModel extends Observable {
  private _selectedTab: number = 0;
  private _messages: Array<Message> = [];
  private _categories: Array<Category> = [];
  private _notificationsEnabled: boolean = true;

  constructor() {
    super();
    this.initializeData();
  }

  private initializeData() {
    // Sample categories
    this._categories = [
      { name: 'Exams', enabled: true },
      { name: 'Assignments', enabled: true },
      { name: 'Hackathons', enabled: true },
      { name: 'Competitions', enabled: true },
      { name: 'Interviews', enabled: true },
      { name: 'Events', enabled: true },
      { name: 'Administrative', enabled: true }
    ];

    // Sample messages
    this._messages = [
      {
        category: 'Exams',
        content: 'Mid-term examinations scheduled for next week',
        timestamp: new Date().toISOString(),
        important: true
      },
      {
        category: 'Assignments',
        content: 'Database project submission deadline extended',
        timestamp: new Date().toISOString(),
        important: false
      }
    ];

    this.notifyPropertyChange('categories', this._categories);
    this.notifyPropertyChange('messages', this._messages);
  }

  get selectedTab(): number {
    return this._selectedTab;
  }

  set selectedTab(value: number) {
    if (this._selectedTab !== value) {
      this._selectedTab = value;
      this.notifyPropertyChange('selectedTab', value);
    }
  }

  get messages(): Array<Message> {
    return this._messages;
  }

  get categories(): Array<Category> {
    return this._categories;
  }

  get notificationsEnabled(): boolean {
    return this._notificationsEnabled;
  }

  set notificationsEnabled(value: boolean) {
    if (this._notificationsEnabled !== value) {
      this._notificationsEnabled = value;
      this.notifyPropertyChange('notificationsEnabled', value);
    }
  }
}