import { Observable } from '@nativescript/core';
import { navigate } from '../../utils/navigation';
import { requestWhatsAppPermissions, checkWhatsAppInstalled } from '../../utils/permissions';
import { alert } from '@nativescript/core/ui/dialogs';

export class LoginViewModel extends Observable {
  private _email: string = '';
  private _password: string = '';
  private _isLoading: boolean = false;

  constructor() {
    super();
  }

  get email(): string {
    return this._email;
  }

  set email(value: string) {
    if (this._email !== value) {
      this._email = value;
      this.notifyPropertyChange('email', value);
    }
  }

  get password(): string {
    return this._password;
  }

  set password(value: string) {
    if (this._password !== value) {
      this._password = value;
      this.notifyPropertyChange('password', value);
    }
  }

  get isLoading(): boolean {
    return this._isLoading;
  }

  set isLoading(value: boolean) {
    if (this._isLoading !== value) {
      this._isLoading = value;
      this.notifyPropertyChange('isLoading', value);
    }
  }

  async onLogin() {
    this.isLoading = true;
    try {
      // Check if WhatsApp is installed
      if (!checkWhatsAppInstalled()) {
        await alert({
          title: "WhatsApp Not Found",
          message: "Please install WhatsApp to use this application.",
          okButtonText: "OK"
        });
        return;
      }

      // Request permissions
      const hasPermissions = await requestWhatsAppPermissions();
      if (!hasPermissions) {
        await alert({
          title: "Permissions Required",
          message: "This app needs access to storage to read WhatsApp messages.",
          okButtonText: "OK"
        });
        return;
      }

      // TODO: Implement actual authentication
      await new Promise(resolve => setTimeout(resolve, 1000));
      navigate('pages/dashboard/dashboard-page');
    } catch (error) {
      console.error('Login failed:', error);
      await alert({
        title: "Error",
        message: "Login failed. Please try again.",
        okButtonText: "OK"
      });
    } finally {
      this.isLoading = false;
    }
  }
}