import { Application, Folder, knownFolders, Utils } from '@nativescript/core';
import { request, RequestPermission } from '@nativescript/permissions';

export async function requestWhatsAppPermissions(): Promise<boolean> {
    try {
        if (Application.android) {
            const permissions = [
                android.Manifest.permission.READ_EXTERNAL_STORAGE,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ];
            
            for (const permission of permissions) {
                const result = await request(permission as RequestPermission);
                if (!result) {
                    return false;
                }
            }
        }
        
        // For iOS, permissions are handled through Info.plist
        return true;
    } catch (error) {
        console.error('Error requesting permissions:', error);
        return false;
    }
}

export function checkWhatsAppInstalled(): boolean {
    try {
        if (Application.android) {
            const packageManager = Utils.android.getApplicationContext().getPackageManager();
            try {
                packageManager.getPackageInfo('com.whatsapp', 0);
                return true;
            } catch (e) {
                return false;
            }
        } else if (Application.ios) {
            return Utils.ios.openFile('whatsapp://');
        }
        return false;
    } catch (error) {
        console.error('Error checking WhatsApp installation:', error);
        return false;
    }
}